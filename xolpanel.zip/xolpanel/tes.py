@bot.on(events.NewMessage(pattern="/start"))
async def start(event):
	await event.reply("@verif_ataaxd_bot")


print("welcome")
